<?php
global $wp;
$order_id = $wp->query_vars['ahoj-pay'];
$order = wc_get_order($order_id);
if (!$order) {
    return;
}

$method = $order->get_payment_method();

if ($method === 'ahoj') {
    $gateway = WC()->payment_gateways->payment_gateways()[$method];
} else {
    return 'Wrong payment  method';
}
$businessPlace = $gateway->businessPlace;
$eshopKey = $gateway->eshopKey;

if (empty($businessPlace) || empty($eshopKey)) {
    echo 'Empty credentials';
    return;
}


include WCGA_PLUGIN_DIR.'/lib/ahoj-pay.php';

$createOrderActionName = "createOrderAndReturnApplicationUrl";
$currentUrl = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["HTTP_HOST"] . explode("?", $_SERVER["REQUEST_URI"], 2)[0];

try {
    $ahojPay = new Ahoj\AhojPay(array(
        "mode" => ($gateway->testmode)? "test":"prod",
        "businessPlace" => $businessPlace,
        "eshopKey" => $eshopKey,
        "notificationCallbackUrl" =>  get_rest_url( null, 'ahoj_pay/orders/'.$order->get_id() ),
    ));
} catch (Exception $exp) {
    echo $exp->getMessage() ? $exp->getMessage() : 'Internal Server Error';
    return;
}

try {
    echo $ahojPay->generateInitJavaScriptHtml();
} catch (Exception $exp) {
    
}

$thankyou_url = $order->get_checkout_order_received_url();
$cancel_url = $order->get_cancel_order_url();




if ($_GET["action"] === $createOrderActionName) {
    $goods= [];
    foreach( $order->get_items() as $item_id => $item ){
        $product = wc_get_product( $item['product_id'] );
        $is_virtual = $product->is_virtual();
       
        $goods[] = [
           'id' => $item['name'],
           'name' =>  $item['name'],
           'count' => $item['quantity'],
           'price' => $item['total'] / $item['quantity'],
           'typeText' => "goods",
           'nonMaterial' => true,//$is_virtual,
           'codeText' => [],
           'commodityText' => [],
           'additionalServices' => []
       ];
      
    }
    $applicationParams = array(
        "orderNumber" => $order->get_order_number(),
        "completionUrl" => $thankyou_url,
        "terminationUrl" => $cancel_url,
        "eshopRegisteredCustomer" => false,
        "customer" => array(
            "firstName" => $order->get_billing_first_name(),
            "lastName" => $order->get_billing_last_name(),
            "contactInfo" => array(
                "email" => $order->get_billing_email(),
                "mobile" => $order->get_billing_phone(),
            ),
            "permanentAddress" => array(
                "street" => $order->get_billing_address_1(),
//                "registerNumber" => false,
                "city" => $order->get_billing_city(),
                "zipCode" => $order->get_billing_postcode(),
            )
        ),
        "product" => array(
            "goods" => $goods
            ,
            "goodsDeliveryTypeText" => $order->get_shipping_method(),
            "goodsDeliveryCosts" => $order->get_shipping_total(),
            "goodsDeliveryAddress" => array(
                "name" => "courier",
                "street" => $order->get_shipping_address_1(),
                "registerNumber" => $order_id,
                "city" => $order->get_shipping_city(),
                "zipCode" => $order->get_shipping_postcode(),
                "country" => $order->get_shipping_country(),
            )
        )
    );
    


    try {
        $result = $ahojPay->createApplication($applicationParams);
        $applicationUrl = $result['applicationUrl'];
        ?>
        <script type ="text/javascript "> 
        (function () {
                console.log('<?php echo $thankyou_url;  ?>');
                ahojpay.openApplication('<?php echo $applicationUrl ?>');
        }) ();
        </script>
        <?php
//        echo json_encode($result);
    } catch (Exception $exp) {
        
        if ($exp instanceof Ahoj\InvalidArgumentException) {
            http_response_code(400);
            echo $exp->getMessage();
            exit();
        }
        if ($exp instanceof Ahoj\TotalPriceExceedsLimitsException) {
            http_response_code(400);
            echo '<pre>';
            print_r($exp);
            echo '</pre>';
           // echo "Celkova cena objednavky je prilis vysoka pre platobnu metodu AhojPay. Vyberte prosim iny sposob platby.";
       //     echo "The total price of the order is too high for the AhojPay payment method. Please choose another method of payment.";
            exit();
        }
        echo $exp->getMessage() ? $exp->getMessage() : 'Internal Server Error';
        http_response_code(500);
    }
}
exit();
