<?php

defined('ABSPATH') || exit;

if (!class_exists('AHOJ_Gateway_loader')) {

    class AHOJ_Gateway_loader {

        /**
         * Constructor
         */
        public function __construct() {
            
            add_filter('woocommerce_payment_gateways', [$this, 'wc_ahoj_add_to_gateways']);
            add_filter('woocommerce_checkout_redirect_empty_cart', array($this, 'prevent_redirect'), 99);
            add_filter('wc_get_template', array($this, 'override_template'), 99, 5);
            add_action('woocommerce_before_thankyou', array($this,  'mark_payment_complete'), 99, 1);
            add_action('woocommerce_after_add_to_cart_button', array($this, 'add_ahoj_terms'));
            add_filter('plugin_action_links_' . WCGA_PLUGIN_SLUG, array($this, 'ahoj_settings_link'));
            add_action( 'rest_api_init', array($this, 'register_notification_route'));
            add_filter('woocommerce_available_payment_gateways', array($this, 'hide_ahoj_payment'));
            
        }
        
        function wc_ahoj_add_to_gateways($gateways) {

            include_once 'class-ahoj-payment-gateway.php';
            $gateways[] = 'WC_Gateway_AHOJ';
            return $gateways;
        }

        /**
         * Prevent redirection on checkout if user is paying for pending order.
         * @global object $wp
         * @param string $redirect
         * @return boolean
         */
        function prevent_redirect($redirect) {
            global $wp;

            if (isset($wp->query_vars['ahoj-pay'])) {
                $order_id = absint($wp->query_vars['ahoj-pay']);
                $order = wc_get_order($order_id);
               
                return false;
                if ($order->needs_payment() && 'ahoj' === $order->get_payment_method()) {
                    return false;
                }
            }
            return $redirect;
        }

        function override_template($template, $template_name, $args, $template_path, $default_pat) {
            global $wp;
  
             if( isset($_REQUEST['cancel_order']) && $_REQUEST['cancel_order'] &&  isset($_REQUEST['amp;order_id']) && $_REQUEST['amp;order_id'] ){
                $order_id =  $_REQUEST['amp;order_id'];
                $order = wc_get_order($order_id);
                $note = 'Order cancelled by Ahoj';
                $order->add_order_note($note);
                $order->update_status('wc-failed');
                
            }
            
            if (!empty($wp->query_vars['ahoj-pay'])) {

                   
                if ($template_name == 'checkout/form-checkout.php') {
                 
                    $template = WCGA_PLUGIN_DIR . '/woocommerce/checkout/ahoj-pay.php';
                    
                    
                }
            }

            return $template;
        }
        
        function mark_payment_complete($order_id) { 
    
            $order = wc_get_order($order_id); 
            
            if ( !$order->is_paid() && 'ahoj' === $order->get_payment_method() ) {
                        $note = 'Payment completed on Ahoj';
                        $order->add_order_note($note);
                        $order->update_status( 'wc-processing' );
                      
            }
        }
        
        function add_ahoj_terms() {
            $img = WCGA_PLUGIN_DIR_URL . '/assets/images/ahoj-logo-bg.svg';
            $gateways = WC()->payment_gateways->get_available_payment_gateways();
            $show_ahoj_message = false;
            $ahojPay_gateway   = null; 
//            pre_print($gateways);
            if ($gateways) {
                foreach ($gateways as $gateway) {

                    if ($gateway->id == 'ahoj' && $gateway->enabled == 'yes') {
                        $ahojPay_gateway = $gateway;
                        $show_ahoj_message = true;
                    }
                }
            }
            if (!$show_ahoj_message) {
                return;
            }
            ?>
            <style>
                    .ahojpay-product-banner{
                            padding-top:  100px;
                    }    
                    .ap-product-banner {
                            font-family: "PublicaSansRegular",sans-serif;
                            background-color: #fff;
                            font-size: 14px;
                            color: #fff;
                            padding: 10px;
                            display: flex;
                            align-items: center;
                            border: 1px solid rgba(86,90,94,0.3);
                            border-radius: 4px;
                            max-width: 420px;
                            width: 100%;
                    }
                    .ap-product-banner__logo {
                            width: 74px;
                            min-width: 45px;
                            height: 43px; 
                            background-image: url(<?= $img ?>);
                            background-size: contain;
                            background-position: center;
                            background-repeat: no-repeat;
                            margin-right: 10px;
                    }

                    .ap-product-banner__title {
                            font-family: "PublicaSansBold",sans-serif;
                            font-size: 14px;
                            line-height: 20px;
                            color: #565a5e;
                            margin: 0;
                            white-space: nowrap;
                            padding-right: 8px;
                    }
                    .ap-product-banner__link {
                            color: #565a5e;
                            padding-top: 2px;
                            white-space: nowrap;
                            text-decoration: underline !important;
                            cursor: pointer;
                    }
                    .ap-product-banner__row {
                            display: flex;
                            align-items: center;
                    }
            </style>
             <script>
                jQuery('document').ready(function ($) {
                    $(document).on('click','.ap-product-banner__link',function(){
                        $('.product-banner__link').click();
                        ahojpay.productBanner(200, '.ahoj-terms');
                    });
                    jQuery('[name=quantity]').change(function(){
                        ahojpay.productBanner(200, '.ahoj-terms');
                    });
                });
            </script>
            <div class="ahojpay-product-banner">
                    <div class="ap-product-banner">
                            <div class="ap-product-banner__logo"></div>
                            <div class="ap-product-banner__row">
                                    <div class="ap-product-banner__title">Kúp teraz, zaplať o 30 dní.</div>
                                    <a class="ap-product-banner__link" >Ako to funguje?</a>
                            </div>
                    </div>
            </div>
            <div class="ahoj-terms" hidden ></div>
            <?php
                global $product;
                $price = $product->get_price();
                $ahojPay = $this->intialize_ahoj_application($ahojPay_gateway);
                if( $ahojPay){
                    echo $ahojPay->generateInitJavaScriptHtml();
                    echo $ahojPay->generateProductBannerHtml( $price, 'ahoj-terms');
                }
            ?>
            
            <?php
        }

        function ahoj_settings_link($links) {
            $url = esc_url(add_query_arg(
                    'page',
                    'wc-settings&tab=checkout&section=ahoj',
                    get_admin_url() . 'admin.php'
                ));
            $settings_link = "<a href='$url'>" . __('Configure') . '</a>';
            
            array_push(
                $links,
                $settings_link
            );
            return $links;
        }
        function intialize_ahoj_application( $gateway ){
           
            include WCGA_PLUGIN_DIR.'/lib/ahoj-pay.php';
            
            $currentUrl = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["HTTP_HOST"] . explode("?", $_SERVER["REQUEST_URI"], 2)[0];
            $notificationCallbackActionName = "ahojNotificationCallbackUrl";
            
            try {
                
                $ahojPay = new Ahoj\AhojPay(array(
                    "mode" => ($gateway->settings['testmode'] == 'yes')? "test":"prod",
                    "businessPlace" => $gateway->settings['businessPlace'],
                    "eshopKey" => $gateway->settings['eshopKey'],
                    "notificationCallbackUrl" => "$currentUrl?action=$notificationCallbackActionName",
                ));
               
            } catch (Exception $exp) {
                echo $exp->getMessage() ? $exp->getMessage() : 'Internal Server Error';
                return false;
            }
              
            return $ahojPay ;
        }
        function register_notification_route(){
       
            register_rest_route( 'ahoj_pay', '/orders/(?P<order_id>\d+)', array(
                'methods' => 'POST',
                'callback' => array( $this, 'payment_status'),
                "permission_callback" => "__return_true",
            ));
        }
        
        function payment_status( WP_REST_Request $request ){
            
            $order_id = $request->get_param( 'order_id' );
            if( empty($order_id)){
                return new WP_Error( 'no_order', 'Invalid order', array( 'status' => 404 ) );
            }
            
            $body_params = $request->get_params();
            if( $body_params['state'] == 'SENT' ){
                return new WP_REST_Response( ['status'=>'success'], 200 );
            }
            
            $order = wc_get_order($order_id);
            if( $body_params['state'] == 'REJECTED' ){
                $note = 'Order rejected by Ahoj';
                $order->add_order_note($note);
                $order->update_status('wc-failed');
            }
       
            return new WP_REST_Response( ['status'=>'success'], 200 );
        }
        
        /**
         * Hide gateway when cart total is outside 10-300 Euro range.
         * @param array $available_gateways
         * @return array
         */
        function hide_ahoj_payment($available_gateways) {
           
            if( is_product() ){
                return $available_gateways;
            }
            if (  WC()->cart  && ( WC()->cart->total < 10 || WC()->cart->total > 300) ) {
                unset($available_gateways['ahoj']);
            }
            return $available_gateways;
        }

        
    }

}
new AHOJ_Gateway_loader();
