<?php

if (!class_exists('WC_Gateway_AHOJ')) {

    class WC_Gateway_AHOJ extends WC_Payment_Gateway {

        /**
         * Constructor for the gateway.
         */
        public function __construct() {

            // Setup general properties.
            $this->setup_properties();

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Get settings.
            $this->title = 'AHOJ - KÚP TERAZ, ZAPLAŤ O 30 DNÍ ';// 'Ahoj Payment';
            $this->testmode = 'yes' === $this->get_option('testmode', 'no');
            $this->businessPlace = $this->get_option('businessPlace', '');
            $this->eshopKey = $this->get_option('eshopKey', '');
            $this->enable_for_methods = $this->get_option('enable_for_methods', array());
            $this->enable_for_virtual = $this->get_option('enable_for_virtual', 'yes') === 'yes';

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            add_filter('woocommerce_gateway_icon', array($this, 'payment_gateway_icon'), 10, 2);
   

        }

        /**
         * Setup general properties for the gateway.
         */
        protected function setup_properties() {
            $this->id = 'ahoj';
            $this->icon = apply_filters('woocommerce_ahoj_icon', '');
            $this->method_title = __('Ahoj Payment', 'woocommerce');
            $this->method_description = __('Have your customers pay with Terms.', 'woocommerce');
            $this->has_fields = true;
            $this->testmode = 'no';
        }

        /**
         * Initialize Gateway Settings Form Fields
         */
        public function init_form_fields() {

            $this->form_fields = apply_filters('wc_ahoj_payment_form_fields', array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'wc-gateway-offline'),
                    'type' => 'checkbox',
                    'label' => __('Enable Ahoj Payments', 'wc-gateway-offline'),
                    'default' => 'yes'
                ),
                'businessPlace' => array(
                    'title' => __('Business Place', 'wc-gateway-offline'),
                    'type' => 'text',
                    'desc_tip' => true,
                ),
                'eshopKey' => array(
                    'title' => __('Eshop Key', 'wc-gateway-offline'),
                    'type' => 'text',
                    'description' => __('Eshop key.', 'wc-gateway-offline'),
                    'desc_tip' => true,
                ),
                'testmode' => array(
                    'title' => __('Ahoj Payments testmode', 'woocommerce'),
                    'type' => 'checkbox',
                    'label' => __('Enable Ahoj Payments testmode', 'woocommerce'),
                    'default' => 'no',
                    /* translators: %s: URL */
                    'description' => '',
                ),
            ));
        }

        public function payment_fields() {
            ?>
            <div id="payment-info" class="payment-info">
                    <ul class="payment-info__list">
                            <li style="list-style: circle !important;">zadarmo a bez úrokov</li>
                            <li style="list-style: circle !important;">platíš kedykoľvek do 30 dní od doručenia</li>
                            <li style="list-style: circle !important;">prvý nákup pre nového klienta do 150 €, <br> ak si klient Ahoj do 300 €</li>
                    </ul>
                    <p class="payment-info__description">Po odoslaní objednávky ťa presmerujeme na Ahoj, kde 
                            <br>
                            prejdeš rýchlym overením a podpíšeš zmluvu online.</p>
                    <br>
                    <p class="payment-info__additional-info">Chcem využiť službu Kúp teraz, zaplať o 30 dní, ktorú <br>
                            poskytuje Ahoj, a. s. 
                            <a href="https://ahoj.shopping/podmienky-odlozenej-platby" target="_blank">Viac informácií.</a>
                    </p>
            </div>

            <?php
            
        }

        public function process_payment($order_id) {
//            include_once 'class-getbalance-api.php';
//            
//            $getbalance_api = new GetBalance_api($this->api_key,$this->vendor_id);
//            $response = $getbalance_api->create_order_transaction( $order_id );
            
                
            $order = wc_get_order($order_id);

            // Mark as on-hold (we're awaiting the payment)
            $order->update_status('on-hold', __('Awaiting GetBalance payment', 'wc-gateway-offline'));

            // Reduce stock levels
            //  $order->reduce_order_stock();
             
            // Remove cart
            //   WC()->cart->empty_cart();
               
            
            $url = wc_get_checkout_url() . 'ahoj-pay/' . $order->get_id() . '/?action=createOrderAndReturnApplicationUrl';
            // Return thankyou redirect
            return array(
                'result' => 'success',
                'redirect' => $url//$this->get_return_url($order),
            );
        }

        

        function payment_gateway_icon($icon, $gateway_id) {

            if ($gateway_id == $this->id) {
                $img = WCGA_PLUGIN_DIR_URL . '/assets/images/ahoj-logo-bg.svg';
                $icon = '<img src="' . $img . '" alt="' . esc_attr($this->title) . '" /> <strong style="color: #a0cc67;">ZADARMO</strong>';
            }

            return $icon;
        }
        
        
       


    }
    // End WC_Gateway_AHOJ
}    
