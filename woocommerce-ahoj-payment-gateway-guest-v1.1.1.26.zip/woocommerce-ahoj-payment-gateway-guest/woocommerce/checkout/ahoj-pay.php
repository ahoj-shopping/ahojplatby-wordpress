<?php

global $wp;

$order_id = $wp->query_vars['ahoj-pay'];
$order = wc_get_order($order_id);
if (!$order) {
    return;
}

$method = $order->get_payment_method();

if ($method === 'ahoj' || $method === 'rozlozto') {
    $gateway = WC()->payment_gateways->payment_gateways()['ahoj'];
} else {
    return 'Wrong payment method';
}

$businessPlace = $gateway->businessPlace;
$eshopKey = $gateway->eshopKey;

if (empty($businessPlace) || empty($eshopKey)) {
    echo 'Empty credentials';
    return;
}

include WCGA_PLUGIN_DIR . '/lib/ahoj-pay.php';

$createOrderActionName = "createOrderAndReturnApplicationUrl";
$currentUrl = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["HTTP_HOST"] . explode("?", $_SERVER["REQUEST_URI"], 2)[0];

try {
    $ahojPay = new Ahoj\AhojPay(array(
        "mode" => ($gateway->testmode) ? "test" : "prod",
        "businessPlace" => $businessPlace,
        "eshopKey" => $eshopKey,
        "notificationCallbackUrl" => get_rest_url(null, 'ahoj_pay/orders/' . $order->get_id()),
    ));
} catch (Exception $exp) {
    echo $exp->getMessage() ? $exp->getMessage() : 'Internal Server Error';
    return;
}

try {
    echo $ahojPay->generateInitJavaScriptHtml();
} catch (Exception $exp) {

}

$thankyou_url = $order->get_checkout_order_received_url();
$cancel_url = $order->get_cancel_order_url();
$tax_enable = (bool) (get_option( 'woocommerce_prices_include_tax' ) == 'yes' || get_option('woocommerce_tax_display_shop')  == 'incl' || get_option( 'woocommerce_tax_display_cart') == 'incl');


if ($_GET["action"] === $createOrderActionName) {
    
    $goods = [];

    foreach ($order->get_items() as $item_id => $item) {
        $product    = $item['variation_id'] ? wc_get_product($item['variation_id']) : wc_get_product($item['product_id']);
        $is_virtual = $product->is_virtual();
        $args       = array( 'qty' => 1 , 'price' => $product->get_sale_price()) ;

        $price_to_display_inc = function_exists( 'wc_get_price_including_tax' ) ? wc_get_price_including_tax( $product , $args ) : $product->get_price_including_tax( 1 , $product->get_sale_price() );
        $price_to_display_exc = function_exists( 'wc_get_price_excluding_tax' ) ? wc_get_price_excluding_tax( $product , $args ) : $product->get_price_excluding_tax( 1 , $product->get_sale_price() );
        $product_price        = ($tax_enable) ? $price_to_display_inc : $price_to_display_exc;
        $id                   = ((string) ($item['sku']) ? $item['sku'] : $item['variation_id']) ? $item['variation_id'] : $item['product_id'];

        // Zoznam produktov
        $goods[] = [
            'id' => "$id",
            'name' => $item['name'],
            'count' => $item['quantity'],
            'price' => $product_price,
            'typeText' => "goods",
            'nonMaterial' => true,//$is_virtual,
            'codeText' => [],
            'commodityText' => [],
            'additionalServices' => []
        ];
    }

    // Zlavy
    $used_coupons = WC()->version < ( float ) ('3.7') ? $order->get_used_coupons() : $order->get_coupon_codes();
    if ( count($used_coupons) > 0 ) {
        foreach ($used_coupons as $code ) {
            if ( ! $code ) {
                continue;
            }

            $discount_coupons[] = new WC_Coupon( $code );
        }

        foreach ( $discount_coupons as $cuponKey => $coupon ) {
            $discounts[] = [
                'code' => sanitize_title( $coupon->get_code() ),
                'label' => $coupon->get_description(),
            ];
        }


        $discount_ammount = -1 * abs(($tax_enable == 1 ) ? $order->get_discount_tax() + $order->get_discount_total() : $order->get_discount_total());
    }

    $coupons = implode(', ',array_column($discounts, 'code'));


    if (!empty($discounts)) {
        $goods[] = array(
            "name" => 'Zľava' .': ' . $coupons,
            "price" => $discount_ammount,
            "id" => "ABATEMENT",
            "typeText" => "ABATEMENT",
            "nonMaterial" => true,
            "commodityText" => array(
                "ABATEMENT"
            ),
            "count" => 1
        );        
    }

    $applicationParams = array(
        "orderNumber" => $order->get_order_number(),
        "completionUrl" => $thankyou_url,
        "terminationUrl" => $cancel_url,
        "eshopRegisteredCustomer" => false,
        "customer" => array(
            "firstName" => $order->get_billing_first_name(),
            "lastName" => $order->get_billing_last_name(),
            "contactInfo" => array(
                "email" => $order->get_billing_email(),
                "mobile" => $order->get_billing_phone(),
            ),
            "permanentAddress" => array(
                "street" => $order->get_billing_address_1(),
                //"registerNumber" => false,
                "city" => $order->get_billing_city(),
                "zipCode" => $order->get_billing_postcode(),
            )
        ),
        "product" => array(
            "goods" => $goods,
            "goodsDeliveryTypeText" => $order->get_shipping_method(),
            "goodsDeliveryCosts" => $order->get_shipping_total(),
            "goodsDeliveryAddress" => array(
                "name" => "courier",
                "street" => $order->get_shipping_address_1(),
                "registerNumber" => $order_id,
                "referenceNumber" => " ",
                "city" => $order->get_shipping_city(),
                "zipCode" => $order->get_shipping_postcode(),
                "country" => $order->get_shipping_country(),
            )
        )
    );


    if ($method === 'ahoj') {
        $promotionCode = 'DP_DEFER_IT';
    } else {
        $promotionCode = 'SP_SPLIT_IT';
    }

    /*echo "<pre>";
    print_r($applicationParams);
    echo "</pre>";
    exit;*/

    try {
        $result = $ahojPay->createApplication($applicationParams, $promotionCode);
        $applicationUrl = $result['applicationUrl'];
        ?>
        <script type="text/javascript ">
            (function () {
                ahojpay.openApplication('<?php echo $applicationUrl ?>');
            })();
        </script>
        <?php

    } catch (Exception $exp) {
        
        if ($exp instanceof Ahoj\InvalidArgumentException) {
            http_response_code(400);
            echo $exp->getMessage();
            exit();
        }
        if ($exp instanceof Ahoj\TotalPriceExceedsLimitsException) {
            echo '<div id="message" class="notice notice-error">';
		    echo esc_html( 'Celková cena objednávky je príliš vysoká pre platobnú metódu AhojPay. Vyberte prosím iný spôsob platby.' );
            echo '</div>';
            exit();
        }
        echo $exp->getMessage() ? $exp->getMessage() : 'Internal Server Error';
        http_response_code(500);
    }
}
exit();
