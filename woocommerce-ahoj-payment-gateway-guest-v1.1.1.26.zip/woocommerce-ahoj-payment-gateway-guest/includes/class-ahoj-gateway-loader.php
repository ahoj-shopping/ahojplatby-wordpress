<?php

use Delisend\WC\WC_Delisend_Loader;

defined('ABSPATH') || exit;

if (!class_exists('AHOJ_Gateway_loader')) {

    class AHOJ_Gateway_loader {

        /**
         * @var AHOJ_Gateway_loader
         */
        private static $instance;

        /** @var Ahoj\AhojPay */
        private static $connection;

        /**
         * Constructor
         */
        public function __construct() {

            add_filter('woocommerce_payment_gateways', [$this, 'wc_ahoj_add_to_gateways']);
            add_filter('woocommerce_checkout_redirect_empty_cart', array($this, 'prevent_redirect'), 99);
            add_filter('wc_get_template', array($this, 'override_template'), 99, 5);
            add_action('woocommerce_before_thankyou', array($this,  'mark_payment_complete'), 99, 1);
            add_action('woocommerce_after_add_to_cart_button', array($this, 'add_ahoj_terms'));
            add_filter('plugin_action_links_' . WCGA_PLUGIN_SLUG, array($this, 'ahoj_settings_link'));
            add_action('rest_api_init', array($this, 'register_notification_route'));
            add_filter('woocommerce_available_payment_gateways', array($this, 'hide_ahoj_payment'));
            
        }
        
        function wc_ahoj_add_to_gateways($gateways) {
            include_once 'class-ahoj-payment-gateway.php';
            include_once 'class-rozlozto-payment-gateway.php';
            $gateways[] = 'WC_Gateway_AHOJ';
            $gateways[] = 'WC_Gateway_ROZLOZTO';
            return $gateways;
        }

        /**
         * Prevent redirection on checkout if user is paying for pending order.
         * @global object $wp
         * @param string $redirect
         * @return boolean
         */

				function calculateSign($base, $key) {
					$plaintext = substr(sha1($base), 0, 8);
				
					$ciphertext = openssl_encrypt($plaintext, "des-ede3", $key, $options=OPENSSL_RAW_DATA);
					$sign = substr(StrToUpper(bin2hex($ciphertext)),0, 16);
				
					return $sign;
				}

        function prevent_redirect($redirect) {
            global $wp;

            if (isset($wp->query_vars['ahoj-pay'])) {
                $order_id = absint($wp->query_vars['ahoj-pay']);
                $order = wc_get_order($order_id);
               
                return false;
                if ($order->needs_payment() && 'ahoj' === $order->get_payment_method()) {
                    return false;
                }
            }
            return $redirect;
        }

				function override_template($template, $template_name, $args, $template_path, $default_pat) {
						global $wp;

						if( isset($_REQUEST['cancel_order']) && $_REQUEST['cancel_order'] &&  isset($_REQUEST['amp;order_id']) && $_REQUEST['amp;order_id'] ){
								$order_id =  $_REQUEST['amp;order_id'];
								$order = wc_get_order($order_id);
								$note = 'Order cancelled by Ahoj';
								$order->add_order_note($note);
								$order->update_status('wc-failed');
								
						}

						if (!empty($wp->query_vars['ahoj-pay'])) {

							$url = explode("&", explode("?", $_SERVER["REQUEST_URI"], 2)[1], 2)[1];
							$sign = explode("=", $url, 2)[1];
	
							$order_id = absint($wp->query_vars['ahoj-pay']);
							$gateways = WC()->payment_gateways->get_available_payment_gateways();
							$ahojPay_gateway = null;
							if ($gateways) {
									foreach ($gateways as $gateway) {
											if ($gateway->id == 'ahoj' && $gateway->enabled == 'yes') {
													$ahojPay_gateway = $gateway;
													$show_ahoj_message = true;
											}
									}
							}
							$bp = $gateway->settings['businessPlace'];
							$eshopKey = $gateway->settings['eshopKey'];
							$calculatedSign = $this->calculateSign($order_id . $bp, $eshopKey);
	
							$res = false;
	
							if (function_exists("hash_equals")) {
								$res = hash_equals($calculatedSign, $sign);
							} else {
								$res = ($sign === $calculatedSign);
							}

									
							if ($template_name == 'checkout/form-checkout.php' && $res) {
							
								$template = WCGA_PLUGIN_DIR . '/woocommerce/checkout/ahoj-pay.php';	
									
							}
						}

						return $template;
				}
        
        function mark_payment_complete($order_id) { 
    
            $order = wc_get_order($order_id);
            
            if ( !$order->is_paid() && 'ahoj' === $order->get_payment_method() ) {
                        $note = 'Payment completed on Ahoj';
                        $order->add_order_note($note);
                        $order->update_status( 'wc-processing' );
                      
            }
        }
        
        function add_ahoj_terms() {
            $img = WCGA_PLUGIN_DIR_URL . '/assets/images/ahoj-logo-bg.svg';
            $gateways = WC()->payment_gateways->get_available_payment_gateways();
            $show_ahoj_message = false;
            $ahojPay_gateway = null;
            if ($gateways) {
                foreach ($gateways as $gateway) {
                    if ($gateway->id == 'ahoj' && $gateway->enabled == 'yes') {
                        $ahojPay_gateway = $gateway;
                        $show_ahoj_message = true;
                    }
                }
            }

            if (!$show_ahoj_message) {
                return;
            }
            ?>
            <style>
                .ahojpay-product-banner {
                    margin: 20px 0;
                }
            </style>
            <?php
            global $product;
            $ahojPay = self::getConnection ($ahojPay_gateway);
            //$this->connection = $ahojPay;
            if ($ahojPay) {
                $price = $product->get_price();
                echo $ahojPay->generateInitJavaScriptHtml();
                echo $ahojPay->generateProductBannerHtml($price, 'ahojpay-product-banner');
            }
        }

        function ahoj_settings_link($links) {
            $url = esc_url(add_query_arg(
                    'page',
                    'wc-settings&tab=checkout&section=ahoj',
                    get_admin_url() . 'admin.php'
                ));
            $settings_link = "<a href='$url'>" . __('Configure') . '</a>';
            
            array_push(
                $links,
                $settings_link
            );
            return $links;
        }
        function intialize_ahoj_application( $gateway ){
           
            include WCGA_PLUGIN_DIR.'/lib/ahoj-pay.php';
            
            $currentUrl = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["HTTP_HOST"] . explode("?", $_SERVER["REQUEST_URI"], 2)[0];
            $notificationCallbackActionName = "ahojNotificationCallbackUrl";

						// echo "<script>console.log('EshopK: " . $gateway->settings['eshopKey'] . "' );</script>";
            
            try {
                
                $ahojPay = new Ahoj\AhojPay(array(
                    "mode" => ($gateway->settings['testmode'] == 'yes')? "test":"prod",
                    "businessPlace" => $gateway->settings['businessPlace'],
                    "eshopKey" => $gateway->settings['eshopKey'],
                    "notificationCallbackUrl" => "$currentUrl?action=$notificationCallbackActionName",
                ));
               
            } catch (Exception $exp) {
                echo $exp->getMessage() ? $exp->getMessage() : 'Internal Server Error';
                return false;
            }
              
            return $ahojPay ;
        }
        function register_notification_route(){
       
            register_rest_route( 'ahoj_pay', '/orders/(?P<order_id>\d+)', array(
                'methods' => 'POST',
                'callback' => array( $this, 'payment_status'),
                "permission_callback" => "__return_true",
            ));
        }
        
        function payment_status( WP_REST_Request $request ){
            
            $order_id = $request->get_param( 'order_id' );
            if( empty($order_id)){
                return new WP_Error( 'no_order', 'Invalid order', array( 'status' => 404 ) );
            }
            
            $body_params = $request->get_params();
						$order = wc_get_order($order_id);
						if( $body_params['state'] == 'SENT' || $body_params['state'] == 'CREATED' || $body_params['state'] == 'DRAFT' || $body_params['state'] == 'APPROVED'){
							$order->update_status('wc-on-hold');
							return new WP_REST_Response( ['status'=>'success'], 200 );
            }
						if( $body_params['state'] == 'SIGNED' ) {
							$order->update_status('wc-processing');
						}
						if ( $body_params['state'] == 'REJECTED' || $body_params['state'] == 'DELETED' || $body_params['state'] == 'CANCELLED' ) {
								if ( $body_params['state'] == 'REJECTED' ) {
										$note = 'Order rejected by Ahoj';
								}
								if ( $body_params['state'] == 'DELETED' ) {
										$note = 'User has not finished the payment';
								}
								if ( $body_params['state'] == 'CANCELLED' ) {
										$note = 'User has cancelled the payment';
								}
								
								$order->add_order_note($note);
								$order->update_status('wc-failed');
						}
       
            return new WP_REST_Response( ['status'=>'success'], 200 );
        }
        
        /**
         * Hide gateway when cart total is outside 10-300 Euro range.
         * @param array $available_gateways
         * @return array
         */
        function hide_ahoj_payment($available_gateways) {

            if ( is_product() || WC()->cart === null || empty(WC()->cart->get_cart_contents_count())) {
                return $available_gateways;
            }

            $subtotal = WC()->cart->subtotal ?? 0;
            $subtotal_ex_tax = WC()->cart->subtotal_ex_tax ?? 0;

            $cartTotal = (get_option( 'woocommerce_prices_include_tax' ) == 'yes'|| get_option('woocommerce_tax_display_shop')  == 'incl' || get_option( 'woocommerce_tax_display_cart') == 'incl') ? $subtotal : $subtotal_ex_tax ;

            $card_discount = $this->card_discount();
            if ($card_discount > 0) {
                $cartTotal -= $card_discount;
            }

            if (  WC()->cart  && (  $cartTotal < 10 ||  $cartTotal > 300) ) {
                unset($available_gateways['ahoj']);
            }

            if (  WC()->cart  && (  $cartTotal < 50 ||  $cartTotal > 300) ) {
                unset($available_gateways['rozlozto']);
            }

            return $available_gateways;
        }

        public static function getConnection($gateway)
        {
            if (null === self::$connection) {
                self::$instance = new self();
                self::$connection = self::$instance->intialize_ahoj_application($gateway);
            }

            return self::$connection;
        }

        /**
         * @return void
         */
        protected function card_discount(): int
        {
            $discount_total = WC()->cart->get_discount_total();
            $discount_tax_total = WC()->cart->get_cart_discount_tax_total();
            return abs($discount_total + $discount_tax_total);
        }
    }
}

new AHOJ_Gateway_loader();
