<?php

use Ahoj\ApiErrorException;

if (!class_exists('WC_Gateway_ROZLOZTO')) {

    class WC_Gateway_ROZLOZTO extends WC_Payment_Gateway {

        /**
         * Constructor for the gateway.
         */
        public function __construct() {

            // Setup general properties.
            $this->setup_properties();

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Get settings.
            $this->title = 'AHOJ - zaplať v 3 splátkach'; // 'Rozlozto Payment';
            $this->testmode = 'yes' === $this->get_option('testmode', 'no');
            $this->businessPlace = $this->get_option('businessPlace', '');
            $this->eshopKey = $this->get_option('eshopKey', '');
            $this->enable_for_methods = $this->get_option('enable_for_methods', array());
            $this->enable_for_virtual = $this->get_option('enable_for_virtual', 'yes') === 'yes';

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_filter('woocommerce_gateway_icon', array($this, 'payment_gateway_icon'), 10, 2);
        }

        /**
         * Setup general properties for the gateway.
         */
        protected function setup_properties() {
            $this->id = 'rozlozto';
            $this->icon = apply_filters('woocommerce_ahoj_icon', '');
            $this->method_title = __('Ahoj Payment', 'woocommerce');
            $this->method_description = __('Have your customers pay with Terms.', 'woocommerce');
            $this->has_fields = true;
            $this->testmode = 'no';
        }

        /**
         * Initialize Gateway Settings Form Fields
         */
        public function init_form_fields() {

            $this->form_fields = apply_filters('wc_ahoj_payment_form_fields', array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'wc-gateway-offline'),
                    'type' => 'checkbox',
                    'label' => __('Enable Ahoj Payments', 'wc-gateway-offline'),
                    'default' => 'yes'
                ),
                'businessPlace' => array(
                    'title' => __('Business Place', 'wc-gateway-offline'),
                    'type' => 'text',
                    'desc_tip' => true,
                ),
                'eshopKey' => array(
                    'title' => __('Eshop Key', 'wc-gateway-offline'),
                    'type' => 'text',
                    'description' => __('Eshop key.', 'wc-gateway-offline'),
                    'desc_tip' => true,
                ),
                'testmode' => array(
                    'title' => __('Ahoj Payments testmode', 'woocommerce'),
                    'type' => 'checkbox',
                    'label' => __('Enable Ahoj Payments testmode', 'woocommerce'),
                    'default' => 'no',
                    /* translators: %s: URL */
                    'description' => '',
                ),
            ));
        }

        public function payment_fields() {
            $total = WC()->cart->get_total(false);
            $ahojpay = $this->connection();
            if ($ahojpay) {
                $javaScriptHtml = $ahojpay->generateInitJavaScriptHtml();
                $descriptionHtml = $ahojpay->generatePaymentMethodDescriptionHtml($total, 'ahojpay-payment-rozlozto', 'SP_SPLIT_IT');
            }
            ?>
            <style>
                .ahojpay-product-banner ul {
                    margin: 0;
                }
                #payment .payment_methods li .payment_box.payment_method_rozlozto {
                    padding: 0;
                }
                .payment_box.payment_method_rozlozto #payment-info {
                    background-color: #fafafa;
                }
                .ahojpay-payment-rozlozto #payment-info .payment-info__ammount-payment li > span {
                    text-align: center;
                }
                .ahojpay-payment-rozlozto #payment-info .payment-info__ammount-payment li > strong {
                    text-align: center;
                }
                .ahojpay-payment-rozlozto #payment-info .payment-info__ammount-payment li > small {
                    text-align: center;
                }
                .ahojpay-payment-rozlozto #payment-info .payment-info__description {
                    font-size: 11px !important;
                    padding-left: 0px !important;
                    line-height: 15px !important;
                }
                .ahojpay-payment-rozlozto #payment-info .payment-info__additional-info {
                    font-size: 11px !important;
                    padding-left: 0px !important;
                    line-height: 15px !important;
                }
                
            </style>
            <?php 
                if ($javaScriptHtml) {
                    echo $javaScriptHtml;
                }

                if ($descriptionHtml) {
                    echo $descriptionHtml; 
                }
                ?>
                <?php
          
        }

         public function process_payment($order_id) {
//            include_once 'class-getbalance-api.php';
//            
//            $getbalance_api = new GetBalance_api($this->api_key,$this->vendor_id);
//            $response = $getbalance_api->create_order_transaction( $order_id );
            
                
            $order = wc_get_order($order_id);

            // Mark as on-hold (we're awaiting the payment)
            $order->update_status('on-hold', __('Awaiting GetBalance payment', 'wc-gateway-offline'));

            // Reduce stock levels
            //  $order->reduce_order_stock();
             
            // Remove cart
            //   WC()->cart->empty_cart();
               
            $sign = $this->calculateSign($order_id . $this->businessPlace);
            $url = wc_get_checkout_url() . 'ahoj-pay/' . $order->get_id() . '/?action=createOrderAndReturnApplicationUrl' . '&sign=' . $sign;
            // Return thankyou redirect
            return array(
                'result' => 'success',
                'redirect' => $url//$this->get_return_url($order),
            );
        }

        function payment_gateway_icon($icon, $gateway_id) {

            if ($gateway_id == $this->id) {
                $img = WCGA_PLUGIN_DIR_URL . '/assets/images/ahoj-logo-bg.svg';
                $icon = '<img src="' . $img . '" alt="' . esc_attr($this->title) . '" /> <strong style="color: #a0cc67;">ZADARMO</strong>';
            }

            return $icon;
        }

				function calculateSign($base) {
					$plaintext = substr(sha1($base), 0, 8);
				
					$ciphertext = openssl_encrypt($plaintext, "des-ede3", $this->eshopKey, $options=OPENSSL_RAW_DATA);
					$sign = substr(StrToUpper(bin2hex($ciphertext)),0, 16);
				
					return $sign;
				}

        private function connection($gateway = null) {
            if (empty($gateway)) {
                $gateways = WC()->payment_gateways->get_available_payment_gateways();
                $gateway = $gateways['ahoj'];
            }

            if ($gateway) {
                $ahojPay = AHOJ_Gateway_loader::getConnection($gateway);
                return $ahojPay;
            }
            return false;
        }
    }
}