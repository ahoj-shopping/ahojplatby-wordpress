<?php
/**
 * Plugin Name: Ahoj Payment Gateway
 * Description: An eCommerce Payment Gateway.
 * Version: 1.1.1.24
 * Author: 
 * Author URI: 
 * Text Domain: woocommerce-gateway-ahoj
 *
 */

if (!defined('WCGA_PLUGIN_DIR')) {
    define('WCGA_PLUGIN_DIR', __DIR__);
}

if (!defined('WCGA_PLUGIN_DIR_URL')) {
    define('WCGA_PLUGIN_DIR_URL',plugin_dir_url(__FILE__));
}

if (!defined('WCGA_PLUGIN_SLUG')) {
    $slug = plugin_basename( __FILE__ );
    define('WCGA_PLUGIN_SLUG',$slug);
}

function ahoj_pay_endpoints() {
    add_rewrite_endpoint('ahoj-pay', EP_ROOT | EP_PAGES);
}

add_action('init', 'ahoj_pay_endpoints');

function ahoj_pay_query_vars($vars) {
    $vars[] = 'ahoj-pay';

    return $vars;
}

add_filter('query_vars', 'ahoj_pay_query_vars', 0);

function ahoj_pay_flush_rewrite_rules() {
    flush_rewrite_rules();
}

add_action('wp_loaded', 'ahoj_pay_flush_rewrite_rules');
require_once WCGA_PLUGIN_DIR.'/includes/class-ahoj-gateway-loader.php';


if( !function_exists('_wc_log') ){
    function _wc_log($message, $handler = 'product-sync-log') {
        $logger = wc_get_logger(); 
        $log_entry = print_r($message, true);
        $logger->debug( $log_entry,array( 'source' => $handler ));
    }
}
